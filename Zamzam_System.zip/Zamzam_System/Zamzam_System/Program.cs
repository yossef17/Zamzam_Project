﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Zamzam_System;
using ZamzamTravel;

namespace Zamzam_System
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            // السطر اللي تحت ده للتشغيل النهائي (اللوجين)
            Application.Run(new Form1()); 

            // السطر اللي تحت ده للتجربة والسرعة (بيدخلك علطول على العملاء)
            //Application.Run(new CustomersForm());
             //Application.Run(new TripsForm());
            //Application.Run(new BookingsForm());
        }
    }
}
