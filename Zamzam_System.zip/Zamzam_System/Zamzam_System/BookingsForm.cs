﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Zamzam_System;
using ZamzamTravel;

namespace ZamzamTravel
{
    public partial class BookingsForm : Form
    {
        // إعداد الاتصال
        SqlConnection conn = new SqlConnection(@"Data Source=.;Initial Catalog=ZamzamDB;Integrated Security=True;TrustServerCertificate=True");

        // فرضاً إن المتغير اللي عندك اسمه CurrentUserID، لو اسمه مختلف غيره هنا
        int currentUserID = 1;
        public BookingsForm()
        {
            InitializeComponent(); // كدة هيشوفها
        }
        // --- [ 1. حدث تحميل الفورم ] ---
        private void BookingsForm_Load(object sender, EventArgs e)
        {
            FillCustomers(); // جلب العملاء للكومبو بوكس
            FillTrips();    // جلب الرحلات للكومبو بوكس
            LoadBookings(); // عرض الجدول

            // ضبط شكل الجدول
            dgvBookings.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        // --- [ 2. دوال جلب البيانات للـ ComboBoxes ] ---
        void FillCustomers()
        {
            SqlDataAdapter da = new SqlDataAdapter("SELECT CustomerID, Name FROM Customers", conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cbCustomers.DataSource = dt;
            cbCustomers.DisplayMember = "Name";    // الاسم اللي هيظهر
            cbCustomers.ValueMember = "CustomerID"; // الرقم اللي هيتخزن
        }

        void FillTrips()
        {
            SqlDataAdapter da = new SqlDataAdapter("SELECT TripID, TripName FROM Trips", conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cbTrips.DataSource = dt;
            cbTrips.DisplayMember = "TripName";
            cbTrips.ValueMember = "TripID";
        }

        // --- [ 3. دالة عرض جدول الحجوزات الموحدة ] ---
        void LoadBookings()
        {
            try
            {
                if (conn.State == ConnectionState.Closed) conn.Open();

                // Query احترافي بـ JOIN عشان نعرض الأسماء بدل الأرقام
                string query = @"SELECT b.BookingID as 'كود الحجز', c.Name as 'اسم العميل', 
                                 t.TripName as 'الرحلة', b.BookingDate as 'تاريخ الحجز', 
                                 b.TotalAmount as 'المبلغ الإجمالي', b.Status as 'الحالة'
                                 FROM Bookings b 
                                 JOIN Customers c ON b.CustomerID = c.CustomerID 
                                 JOIN Trips t ON b.TripID = t.TripID";

                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvBookings.DataSource = dt;

                dgvBookings.ClearSelection(); // عشان ميبقاش متعلم على حاجة
                conn.Close();
            }
            catch (Exception ex)
            {
                if (conn.State == ConnectionState.Open) conn.Close();
                MessageBox.Show("خطأ في تحميل الحجوزات: " + ex.Message);
            }
        }

        // --- [ 4. أزرار العمليات ] ---

        // زرار حجز رحلة (إضافة)
        private void btnAddBooking_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbCustomers.SelectedValue == null || cbTrips.SelectedValue == null)
                {
                    MessageBox.Show("من فضلك اختر العميل والرحلة أولاً");
                    return;
                }

                conn.Open();
                string query = "INSERT INTO Bookings (TripID, CustomerID, UserID, BookingDate, TotalAmount, Status) " +
                               "VALUES (@trip, @cust, @user, @date, @amount, @status)";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@trip", cbTrips.SelectedValue);
                cmd.Parameters.AddWithValue("@cust", cbCustomers.SelectedValue);
                cmd.Parameters.AddWithValue("@user", currentUserID); // المتغير بتاعك
                cmd.Parameters.AddWithValue("@date", dtpBookingDate.Value);
                cmd.Parameters.AddWithValue("@amount", decimal.Parse(txtTotalAmount.Text));
                cmd.Parameters.AddWithValue("@status", cbStatus.Text); // القائمة اللي إنت ضفتها

                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("تم تسجيل الحجز بنجاح يا يوسف");
                LoadBookings();
                ClearFields();
            }
            catch (Exception ex)
            {
                if (conn.State == ConnectionState.Open) conn.Close();
                MessageBox.Show("خطأ في الحجز: " + ex.Message);
            }
        }

        // زرار مسح الخانات
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        void ClearFields()
        {
            txtTotalAmount.Clear();
            dtpBookingDate.Value = DateTime.Now;
            cbStatus.SelectedIndex = 0;
            dgvBookings.ClearSelection();
        }

        // زرار الطباعة
        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (dgvBookings.CurrentRow != null)
                MessageBox.Show("جاري استخراج فاتورة الحجز...");
            else
                MessageBox.Show("اختر حجزاً من الجدول لطباعته");
        }

        // --- [ 5. جلب السعر تلقائياً عند تغيير الرحلة ] ---
        private void cbTrips_SelectedIndexChanged(object sender, EventArgs e)
        {
            // دي حركة بتجيب السعر من جدول الرحلات فوراً
            if (cbTrips.SelectedValue != null && cbTrips.ValueMember != "")
            {
                try
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT Price FROM Trips WHERE TripID = @id", conn);
                    cmd.Parameters.AddWithValue("@id", cbTrips.SelectedValue);
                    object price = cmd.ExecuteScalar();
                    if (price != null) txtTotalAmount.Text = price.ToString();
                    conn.Close();
                }
                catch { conn.Close(); }
            }
        }

        // --- [ 6. أزرار التنقل بين الصفحات ] ---
        // زرار الانتقال لصفحة الحجوزات
        private void btnBookings_Click(object sender, EventArgs e)
        {
            new BookingsForm().Show();
            this.Hide();
            // Close أفضل من Hide عشان ما يفضلش البرنامج شغال في الخلفية
        }
        private void btnCustomers_Click(object sender, EventArgs e)
        {
            new CustomersForm().Show();
            this.Hide();
        }

        private void btnTrips_Click(object sender, EventArgs e)
        {
            new TripsForm().Show();
            this.Hide();
        }

        // زرار تسجيل الخروج وإغلاق البرنامج بالكامل
        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult check = MessageBox.Show("هل أنت متأكد من إغلاق البرنامج؟", "نظام زمزم", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (check == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void lblWelcome_Click(object sender, EventArgs e)
        {
            new MainDashboard("زمزم للسياحة").Show();
            this.Hide();
        }

        // منعاً للتحديد التلقائي
        private void dgvBookings_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            dgvBookings.ClearSelection();
        }
private void btnDeleteBooking_Click(object sender, EventArgs e)
{
    // 1. التأكد إن اليوزر اختار سطر من الجدول
    if (dgvBookings.CurrentRow != null)
    {
        // 2. أخذ رقم الحجز (الـ ID) من أول عمود في الجدول
        string bookingId = dgvBookings.CurrentRow.Cells[0].Value.ToString();

        if (MessageBox.Show("هل أنت متأكد من حذف هذا الحجز؟", "تنبيه", MessageBoxButtons.YesNo) == DialogResult.Yes)
        {
            try
            {
                conn.Open();
                // 3. المسح باستخدام الـ BookingID حصراً
                string query = "DELETE FROM Bookings WHERE BookingID = @id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", bookingId);
                
                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("تم حذف الحجز بنجاح");
                LoadBookings(); // تحديث الجدول عشان الحجز يختفي
            }
            catch (Exception ex)
            {
                if (conn.State == ConnectionState.Open) conn.Close();
                MessageBox.Show("خطأ في المسح: " + ex.Message);
            }
        }
    }
    else
    {
        MessageBox.Show("يرجى اختيار الحجز المراد حذفه من الجدول أولاً");
    }
}
    }
}