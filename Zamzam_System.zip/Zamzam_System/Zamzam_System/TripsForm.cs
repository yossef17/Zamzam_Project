﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using ZamzamTravel;

namespace Zamzam_System
{
    public partial class TripsForm : Form
    {
        // إعداد اتصال قاعدة البيانات (الخادم المحلي وقاعدة بيانات زمزم)
        SqlConnection conn = new SqlConnection(@"Data Source=.;Initial Catalog=ZamzamDB;Integrated Security=True;TrustServerCertificate=True");

        public TripsForm()
        {
            InitializeComponent();
        }

        // --- [ 1. دالة عرض البيانات ] ---
        // وظيفتها تجلب بيانات الرحلات من SQL وتحدث الجدول (dgvTrips)
        void LoadTrips()
        {
            try
            {
                if (conn.State == ConnectionState.Closed) conn.Open();

                // الأسماء هنا مطابقة للـ Query اللي إنت بعتها بالظبط
                string query = "SELECT TripID, TripName, Capacity, Price, StartDate FROM Trips";

                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvTrips.ClearSelection();
                dgvTrips.DataSource = dt;
                conn.Close();
            }
            catch (Exception ex)
            {
                if (conn.State == ConnectionState.Open) conn.Close();
                MessageBox.Show("خطأ في تحميل الجدول: " + ex.Message);
            }
        }

        // --- [ 2. حدث تشغيل الفورم ] ---
        private void TripsForm_Load(object sender, EventArgs e)
        {
            LoadTrips();
        }

        // --- [ 3. زرار إضافة رحلة جديدة ] ---
        // --- [ 3. زرار إضافة رحلة جديدة ] ---
        private void btnAddTrip_Click(object sender, EventArgs e)
        {
            try
            {
                // التحقق من الحقول
                if (string.IsNullOrEmpty(txtTripName.Text) || string.IsNullOrEmpty(txtPrice.Text))
                {
                    MessageBox.Show("من فضلك أدخل اسم الرحلة وسعرها أولاً", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                conn.Open();
                // ظبطنا المسميات هنا: Capacity بدلاً من Duration
                string query = "INSERT INTO Trips (TripName, Price, Capacity, StartDate) VALUES (@name, @price, @cap, @date)";
                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@name", txtTripName.Text);
                cmd.Parameters.AddWithValue("@price", decimal.Parse(txtPrice.Text));
                cmd.Parameters.AddWithValue("@cap", txtCapacity.Text); // بياخد من TextBox السعة
                cmd.Parameters.AddWithValue("@date", dtpStartDate.Value);

                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("تمت إضافة الرحلة بنجاح ", "نجاح العملية", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadTrips();
                ClearFields();
            }
            catch (Exception ex)
            {
                if (conn.State == ConnectionState.Open) conn.Close();
                MessageBox.Show("خطأ في إضافة الرحلة: " + ex.Message);
            }
        }

        // --- [ 4. زرار تعديل بيانات الرحلة ] ---
        private void btnUpdateTrip_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvTrips.CurrentRow == null)
                {
                    MessageBox.Show("اختر رحلة من الجدول أولاً لتعديلها");
                    return;
                }

                // التأكد من اسم عمود الكود في الجدول
                string tripID = dgvTrips.CurrentRow.Cells["TripID"].Value.ToString();

                conn.Open();
                // ظبطنا المسميات في التعديل برضه
                string query = "UPDATE Trips SET TripName=@name, Price=@price, Capacity=@cap, StartDate=@date WHERE TripID=@id";
                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@id", tripID);
                cmd.Parameters.AddWithValue("@name", txtTripName.Text);
                cmd.Parameters.AddWithValue("@price", decimal.Parse(txtPrice.Text));
                cmd.Parameters.AddWithValue("@cap", txtCapacity.Text);
                cmd.Parameters.AddWithValue("@date", dtpStartDate.Value);

                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("تم تعديل بيانات الرحلة بنجاح");
                LoadTrips();
                ClearFields();
            }
            catch (Exception ex)
            {
                if (conn.State == ConnectionState.Open) conn.Close();
                MessageBox.Show("خطأ في التعديل: " + ex.Message);
            }
        }

        // --- [ 5. زرار حذف الرحلة ] ---
        private void btnDeleteTrip_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvTrips.CurrentRow == null)
                {
                    MessageBox.Show("اختر رحلة أولاً لحذفها");
                    return;
                }

                if (MessageBox.Show("هل تريد حذف هذه الرحلة نهائياً؟", "تأكيد الحذف", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    string tripID = dgvTrips.CurrentRow.Cells["TripID"].Value.ToString();

                    conn.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM Trips WHERE TripID=@id", conn);
                    cmd.Parameters.AddWithValue("@id", tripID);
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("تم حذف الرحلة بنجاح");
                    LoadTrips();
                    ClearFields();
                }
            }
            catch (Exception ex)
            {
                if (conn.State == ConnectionState.Open) conn.Close();
                MessageBox.Show("خطأ في الحذف: " + ex.Message);
            }
        }

        // --- [ 6. زرار مسح الخانات ] ---
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        void ClearFields()
        {
            txtTripName.Clear();
            txtPrice.Clear();
            txtCapacity.Clear();
            dtpStartDate.Value = DateTime.Now;
            txtTripName.Focus();
        }

        // --- [ 7. أزرار المنيو والتنقل ] ---

        private void btnTrips_Click(object sender, EventArgs e)
        {
            LoadTrips();
        }
        private void btnCustomers_Click(object sender, EventArgs e)
        {
            new CustomersForm().Show();
            this.Hide();
        }

        private void btnBookings_Click(object sender, EventArgs e)
        {
            new BookingsForm().Show();
            this.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("هل أنت متأكد من إغلاق البرنامج؟", "نظام زمزم", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void lblWelcome_Click(object sender, EventArgs e)
        {
            new MainDashboard("زمزم للسياحة").Show();
            this.Hide();
        }

        // --- [ 8. حدث الضغط على الجدول ] ---
        private void dgvTrips_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvTrips.Rows[e.RowIndex];

                // الأسماء داخل [" "] لازم تكون زي اللي في السيكوال فوق
                txtTripName.Text = row.Cells["TripName"].Value.ToString();
                txtPrice.Text = row.Cells["Price"].Value.ToString();

                // لو عامل TextBox للـ Capacity (السعة)
                if (row.Cells["Capacity"].Value != null)
                    txtCapacity.Text = row.Cells["Capacity"].Value.ToString();

                if (row.Cells["StartDate"].Value != DBNull.Value)
                {
                    dtpStartDate.Value = Convert.ToDateTime(row.Cells["StartDate"].Value);
                }
            }
        }

        private void dgvTrips_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            dgvTrips.ClearSelection();
        }

    }
}