﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZamzamTravel;

namespace Zamzam_System
{
    public partial class CustomersForm : Form
    {
        // إعداد اتصال قاعدة البيانات (الخادم المحلي وقاعدة بيانات زمزم)
        SqlConnection conn = new SqlConnection(@"Data Source=.;Initial Catalog=ZamzamDB;Integrated Security=True");

        public CustomersForm()
        {
            InitializeComponent();
        }

        // --- [ 1. دالة عرض البيانات ] ---
        // وظيفتها تجلب البيانات من SQL وتحدث الجدول (DataGridView)
        void LoadData()
        {
            try
            {
                if (conn.State == ConnectionState.Closed) conn.Open();
                string query = "SELECT Name, National_ID, Phone, Passport_Expiry FROM Customers";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvCustomers.DataSource = dt; // ربط البيانات بالجدول في الفورم
                dgvCustomers.ClearSelection(); // السطر ده بيلغي "المغناطيس"
                conn.Close();
            }
            catch (Exception ex)
            {
                if (conn.State == ConnectionState.Open) conn.Close();
                MessageBox.Show("خطأ في تحميل الجدول: " + ex.Message);
            }
        }

        // --- [ 2. حدث تشغيل الفورم ] ---
        // يتم استدعاء LoadData بمجرد فتح الشاشة
        private void CustomersForm_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        // --- [ 3. زرار إضافة عميل جديد ] ---
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                // التحقق من إدخال الحقول الإلزامية
                if (string.IsNullOrEmpty(txtNationalID.Text) || string.IsNullOrEmpty(txtName.Text))
                {
                    MessageBox.Show("من فضلك أدخل الرقم القومي والاسم");
                    return;
                }

                conn.Open();
                string query = "INSERT INTO Customers (National_ID, Name, Phone, Passport_Expiry) VALUES (@id, @name, @phone, @expiry)";
                SqlCommand cmd = new SqlCommand(query, conn);

                // استخدام الباراميترز لمنع ثغرات الـ SQL Injection
                cmd.Parameters.AddWithValue("@id", txtNationalID.Text);
                cmd.Parameters.AddWithValue("@name", txtName.Text);
                cmd.Parameters.AddWithValue("@phone", txtPhone.Text);
                cmd.Parameters.AddWithValue("@expiry", dtpExpiry.Value);

                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("تمت إضافة العميل بنجاح");
                LoadData();      // تحديث الجدول فوراً
                ClearFields();   // تنظيف الخانات للكتابة مرة أخرى
            }
            catch (Exception ex)
            {
                if (conn.State == ConnectionState.Open) conn.Close();
                MessageBox.Show("خطأ في الإضافة: " + ex.Message);
            }
        }

        // --- [ 4. زرار تعديل البيانات ] ---
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtNationalID.Text))
                {
                    MessageBox.Show("اختر عميل أولاً من الجدول للتعديل");
                    return;
                }

                conn.Open();
                string query = "UPDATE Customers SET Name=@name, Phone=@phone, Passport_Expiry=@expiry WHERE National_ID=@id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", txtNationalID.Text);
                cmd.Parameters.AddWithValue("@name", txtName.Text);
                cmd.Parameters.AddWithValue("@phone", txtPhone.Text);
                cmd.Parameters.AddWithValue("@expiry", dtpExpiry.Value);

                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("تم تعديل بيانات العميل");
                LoadData();
            }
            catch (Exception ex) { if (conn.State == ConnectionState.Open) conn.Close(); MessageBox.Show(ex.Message); }
        }

        // --- [ 5. زرار حذف العميل ] ---
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtNationalID.Text)) return;

                // رسالة تأكيد قبل الحذف الفعلي
                if (MessageBox.Show("هل تريد حذف هذا العميل نهائياً؟", "تنبيه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM Customers WHERE National_ID=@id", conn);
                    cmd.Parameters.AddWithValue("@id", txtNationalID.Text);
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("تم الحذف بنجاح");
                    LoadData();
                    ClearFields();
                }
            }
            catch (Exception ex) { if (conn.State == ConnectionState.Open) conn.Close(); MessageBox.Show(ex.Message); }
        }

        // --- [ 6. زرار مسح الخانات ] ---
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        // دالة تنظيف أدوات الإدخال
        void ClearFields()
        {
            txtNationalID.Clear();
            txtName.Clear();
            txtPhone.Clear();
            dtpExpiry.Value = DateTime.Now;
        }

        // --- [ 7. أزرار المنيو والتنقل ] ---
        // زرار يوديك للرحلات
        private void btnTrips_Click(object sender, EventArgs e)
        {
            new TripsForm().Show();
            this.Hide();
        }

        private void btnBookings_Click(object sender, EventArgs e)
        {
            new BookingsForm().Show();
            this.Hide();
        }

        private void btnCustomers_Click(object sender, EventArgs e)
        {
            LoadData(); // ريفريش للبيانات
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            // بنسأل المستخدم للتأكيد
            DialogResult check = MessageBox.Show("هل أنت متأكد من إغلاق البرنامج؟", "نظام زمزم", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // لو داس Yes هيقفل البرنامج كله
            if (check == DialogResult.Yes)
            {
                Application.Exit(); // دي بتقفل كل الفورمز وكل العمليات اللي شغالة في الخلفية
            }

            // لو داس No مش هيعمل حاجة وهيفضل في نفس الشاشة
        }

        private void dgvCustomers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // التأكد إن الضغطة مش على رأس الجدول
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvCustomers.Rows[e.RowIndex];

                // نقل البيانات من الصف المختار للتكست بوكس
                txtNationalID.Text = row.Cells["National_ID"].Value.ToString();
                txtName.Text = row.Cells["Name"].Value.ToString();
                txtPhone.Text = row.Cells["Phone"].Value.ToString();

                // لو عندك تاريخ انتهاء الباسبور
                if (row.Cells["Passport_Expiry"].Value != DBNull.Value)
                {
                    dtpExpiry.Value = Convert.ToDateTime(row.Cells["Passport_Expiry"].Value);
                }
            }
        }

        private void lblWelcome_Click(object sender, EventArgs e)
        {
            try
            {
                // 1. بننشئ نسخة من الداشبورد ونبعت لها النص
                MainDashboard main = new MainDashboard("زمزم للسياحة");

                // 2. بنظهر الداشبورد
                main.Show();

                // 3. بدل Close هنستخدم Hide عشان البرنامج ميفصلش فجأة
                this.Hide();
            }
            catch (Exception ex)
            {
                // لو في أي مشكلة هتظهر لك رسالة تقولك فين الغلط بدل ما يقفل
                MessageBox.Show("خطأ في فتح الداشبورد: " + ex.Message);
            }
        }

    }
}