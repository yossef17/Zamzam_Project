﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Zamzam_System;
using ZamzamTravel;

namespace Zamzam_System
{
    public partial class MainDashboard : Form
    {
        public string CurrentUser;

        public MainDashboard(string loginName)
        {
            InitializeComponent();
            CurrentUser = loginName;
        }

        private void MainDashboard_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = "أهلاً بك يا " + CurrentUser;
        }

        // 1. زرار إدارة العملاء
        private void btnCustomers_Click(object sender, EventArgs e)
        {
            CustomersForm cust = new CustomersForm();
            cust.Show(); // استخدم Show بدل ShowDialog عشان نقدر نتحرك بحرية
            this.Hide(); // نخفي الداشبورد
        }

        // 2. زرار إدارة الرحلات
        private void btnTrips_Click(object sender, EventArgs e)
        {
            TripsForm trips = new TripsForm();
            trips.Show();
            this.Hide();
        }

        // 3. زرار الحجوزات
        private void btnBookings_Click(object sender, EventArgs e)
        {
            BookingsForm book = new BookingsForm();
            book.Show();
            this.Hide();
        }

        // 4. زرار تسجيل الخروج
        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult check = MessageBox.Show("هل أنت متأكد من تسجيل الخروج؟", "نظام زمزم", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (check == DialogResult.Yes)
            {
                Form1 login = new Form1(); // هنا اتأكدنا إن اسم اللوجن Form1
                login.Show();
                this.Close(); // نقفل الداشبورد تماماً
            }
        }

    }
}