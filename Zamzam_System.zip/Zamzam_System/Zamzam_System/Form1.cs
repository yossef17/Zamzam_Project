﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Zamzam_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            // عنوان السيرفر والقاعدة
            string connString = @"Data Source=.;Initial Catalog=ZamzamDB;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connString))
            {
                try
                {
                    con.Open();
                    // الاستعلام بيجيب الاسم والدور
                    string query = "SELECT FullName, Role FROM Users WHERE Username=@user AND Password=@pass";
                    SqlCommand cmd = new SqlCommand(query, con);

                    // نربط مربعات النص بالباراميترز
                    cmd.Parameters.AddWithValue("@user", txtUser.Text.Trim());
                    cmd.Parameters.AddWithValue("@pass", txtPass.Text.Trim());

                    // الـ Reader عشان نسحب كذا معلومة
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        // سحب البيانات من السيكوال
                        string fullName = reader["FullName"].ToString();
                        string role = reader["Role"].ToString();

                        // فتح الداشبورد فوراً
                        MainDashboard dash = new MainDashboard(fullName);

                        // حركة عالمية: نغير عنوان الفورم فوق باسمك
                        dash.Text = "Welcome: " + fullName + " (" + role + ")";

                        this.Hide();
                        dash.Show();
                        dash.TopMost = true;  // السطر ده هيخليها "تجبـر" نفسها تظهر فوق أي حاجة
                        dash.TopMost = false; // وبعدين بنقفلها عشان متفضلش محشورة في الوش طول العمر
                    }
                    else
                    {
                        // الرسالة دي اكتبها بإيدك لو لسه بتطلع Error
                        MessageBox.Show("Wrong Username or Password", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Database Connection Error: " + ex.Message);
                }

            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            // اجعل البانل يتنفس الشفافية
            panel1.BackColor = Color.FromArgb(150, Color.White); // 150 هي درجة الشفافية من 255
        }

    }
}
